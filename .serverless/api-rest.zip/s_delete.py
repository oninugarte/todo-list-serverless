import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='oninugarte',
    application_name='todo-list-serverless',
    app_uid='xHdn2krQ1mKYLLGFhN',
    org_uid='d542d0a9-30ef-4a50-8ec2-71eacf1d9c6a',
    deployment_uid='d9691587-d4c3-4f78-88fe-3397e9b5ba52',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.1.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
